﻿        // (c) Copyright Microsoft Corporation.
        // This source is subject to the Microsoft Permissive License.
        // See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
        // All other rights reserved.

function pageLoad() {
    $get("result").innerHTML = "Pass";
    ToolkitScriptManagerJsType = true;
}
