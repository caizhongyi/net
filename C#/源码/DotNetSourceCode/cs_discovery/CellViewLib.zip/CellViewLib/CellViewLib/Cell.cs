using System;

namespace CellViewLib
{
	/// <summary>
	/// ��Ԫ�����
	/// ���� Ԭ���� 2007-12-26
	/// </summary>
	public class Cell
	{
		private string strText = null;
		/// <summary>
		/// ��Ԫ���ı�
		/// </summary>
		public string Text
		{
			get{ return strText ;}
			set{ strText = value;}
		}
		private bool bolSelected = false;
		/// <summary>
		/// ��Ԫ��ѡ���־
		/// </summary>
		public bool Selected
		{
			get{ return bolSelected ;}
			set{ bolSelected = value;}
		}

		internal int intLeft = 0 ;
		/// <summary>
		/// ��Ԫ�����λ��
		/// </summary>
		public int Left
		{
			get{ return intLeft ;}
		}

		internal int intTop = 0 ;
		/// <summary>
		/// ��Ԫ�񶥶�λ��
		/// </summary>
		public int Top
		{
			get{ return intTop ;}
		}

		internal int intWidth = 0 ;
		/// <summary>
		/// ��Ԫ�����
		/// </summary>
		public int Width
		{
			get{ return intWidth ;}
		}

		internal int intHeight = 0 ;
		/// <summary>
		/// ��Ԫ��߶�
		/// </summary>
		public int Height
		{
			get{ return intHeight ;}
		}

		/// <summary>
		/// ����߽�
		/// </summary>
		public System.Drawing.Rectangle Bounds
		{
			get{ return new System.Drawing.Rectangle( intLeft , intTop , intWidth , intHeight );}
		}
		 
	}//public class Cell
}