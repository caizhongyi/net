#include <windows.h>
#include <windowsx.h>
#include <tchar.h>

HINSTANCE g_hinstDll = NULL;

#pragma data_seg(".drectve")
    static char szLinkDirectiveShared[] = "-section:Shared,rws";
#pragma data_seg()
#pragma data_seg("Shared")

HHOOK g_hhook      = NULL;
HWND  g_hwndPost   = NULL;
UINT  g_uMsgNotify = WM_USER;

#pragma data_seg()

static LRESULT WINAPI KeyboardHook_HookProc (
   int nCode,
   WPARAM wParam, 
   LPARAM lParam) 
{

   LRESULT lResult = CallNextHookEx(g_hhook, nCode, wParam, lParam);

   if (nCode == HC_ACTION) 
   {
      PostMessage(g_hwndPost, g_uMsgNotify, wParam, lParam);
   }
   return(lResult);
}

BOOL WINAPI SetKeyboardHook (HWND hWndPost, UINT Msg) 
{
   HHOOK hhook;

   if (g_hhook != NULL) return(FALSE);

   g_hwndPost   = hWndPost;
   g_uMsgNotify = Msg;
   Sleep(0);

   hhook = SetWindowsHookEx(WH_KEYBOARD, KeyboardHook_HookProc, g_hinstDll, 0);
   InterlockedExchange((PLONG) &g_hhook, (LONG) hhook);
   return(g_hhook != NULL);
}

BOOL WINAPI ReleaseKeyboardHook() 
{
   BOOL fOK = TRUE;

   if (g_hhook != NULL) 
   {
      fOK = UnhookWindowsHookEx(g_hhook);
      g_hhook = NULL;
   }
   return(fOK);
}

BOOL WINAPI DllMain (HINSTANCE hinstDll, DWORD fdwReason, LPVOID lpvReserved) 
{
   switch (fdwReason) 
   {
      case DLL_PROCESS_ATTACH:
         g_hinstDll = hinstDll;
         break;
   }
   return(TRUE);
}
