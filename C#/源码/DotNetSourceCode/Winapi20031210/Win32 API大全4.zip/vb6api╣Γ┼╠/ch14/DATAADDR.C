#include <windows.h>

STDAPI_(LONG) DataAddress(LPVOID data)
{
   return((LONG)data);
}
