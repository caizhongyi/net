<?php
// Version: 2.0 RC2; Modifications

// Important! Before editing these language files please read the text at the top of index.english.php.

?>