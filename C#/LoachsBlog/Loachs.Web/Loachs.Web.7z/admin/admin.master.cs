﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class admin_admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Write("version:" + Request.Browser.Version);

        //Response.Write("<br>");

        //Response.Write("Platform:" + Request.Browser.Platform);

        //Response.Write("<br>");

        //Response.Write("MajorVersion:" + Request.Browser.MajorVersion);

        //Response.Write("<br>");

        //Response.Write("IsMobileDevice:" + Request.Browser.IsMobileDevice);

        //Response.Write("<br>");

        //Response.Write("Crawler:" + Request.Browser.Crawler);

        //Response.Write("<br>");

        //Response.Write("ClrVersion:" + Request.Browser.ClrVersion);

        //Response.Write("<br>");

        //Response.Write("Browser:" + Request.Browser.Browser);

        //Response.Write("<br>");

        //Response.Write("Browsers.count:" + Request.Browser.Browsers.Count);

        //Response.Write("<br>");

        //Response.Write("Is IE 6:" + PageUtils.IsIE6);

        //Response.Write("<br>");

        //Response.Write("UserAgent:" + Request.UserAgent);

    }
}
