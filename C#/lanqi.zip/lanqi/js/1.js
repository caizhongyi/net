// JavaScript Document

function show1(){

document.getElementById("content1").style.display = "block";
document.getElementById("content2").style.display = "none";
    document.getElementById("content3").style.display = "none";

}

function show2(){

document.getElementById("content1").style.display = "none";
    document.getElementById("content2").style.display = "block";
document.getElementById("content3").style.display = "none";

}
function show3(){
document.getElementById("content1").style.display = "none";
document.getElementById("content2").style.display = "none";
document.getElementById("content3").style.display = "block";

}

