﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;
using System.ComponentModel;

namespace Brainsiders.Slide3DToMouse
{
    public class Slide3DToMouse : TargetedTriggerAction<FrameworkElement>
    {
        // properties
        [Description("Angle animation duration (in milliseconds)")]
        [Category("Projection Animation Properties")]
        public int AnimationTime { get; set; } // how long must the animation take

        [Description("The Easing Function assigned to the animation")]
        [Category("Projection Animation Properties")]
        public IEasingFunction Easing { get; set; }

        [Description("The Positive/Negative X Angle amplitude for the perspective transform")]
        [Category("Projection Animation Properties")]
        public double AmplitudeAngleX { get; set; }
        [Category("Slide Animation Properties")]
        public double AmplitudeSlideX { get; set; }

        [Description("The Positive/Negative Y Angle amplitude for the perspective transform")]
        [Category("Projection Animation Properties")]
        public double AmplitudeAngleY { get; set; }
        [Category("Slide Animation Properties")]
        public double AmplitudeSlideY { get; set; }

        [Description("If the projection is oriented towards the mouse or against it.")]
        [Category("Projection Animation Properties")]
        public Boolean ProjectionTowardsMouse { get; set; }

        private TimeSpan tsAnimationTime;
        private FrameworkElement feAssociatedObject;
        private FrameworkElement feSourceObject;
        private FrameworkElement feTargetObject;
        private PlaneProjection ProjectionTargetObject;

        private double SourceWidth;
        private double SourceHeight;
        private Storyboard SB_X;
        private Storyboard SB_Y;

        protected override void Invoke(object parameter)
        {
            FrameworkElement myElement = this.AssociatedObject as FrameworkElement;
        }

        protected override void OnAttached()
        {
            base.OnAttached();
            feAssociatedObject = (FrameworkElement)this.AssociatedObject;
            feSourceObject = (FrameworkElement)this.AssociatedObject;
            tsAnimationTime = new TimeSpan(0, 0, 0, 0, AnimationTime);
            feSourceObject.Loaded += new RoutedEventHandler(feSourceObject_Loaded);
        }

        private void DetermineSourceWidthAndHeight()
        {
            if (double.IsNaN(feSourceObject.ActualWidth) || feSourceObject.ActualWidth == 0)
            {
                SourceWidth = feSourceObject.Width;
            }
            else
            {
                SourceWidth = feSourceObject.ActualWidth;
            }

            if (double.IsNaN(feSourceObject.ActualHeight) || feSourceObject.ActualHeight == 0)
            {
                SourceHeight = feSourceObject.Height;
            }
            else
            {
                SourceHeight = feSourceObject.ActualHeight;
            }
        }
        private Point BasePoint = new Point();
        void feSourceObject_Loaded(object sender, RoutedEventArgs e)
        {
            DetermineSourceWidthAndHeight();
            feSourceObject.MouseEnter += new MouseEventHandler(feSourceObject_MouseEnter);
            feSourceObject.MouseLeave += new MouseEventHandler(feSourceObject_MouseLeave);
            feSourceObject.MouseMove += new MouseEventHandler(feSourceObject_MouseMove);
            ProjectionTargetObject = new PlaneProjection();

            feTargetObject = (FrameworkElement)this.TargetObject;
            if (feTargetObject.Projection == null)
            {
                feTargetObject.RenderTransformOrigin = new Point(0.5, 0.5);
                PlaneProjection pj = new PlaneProjection();
                feTargetObject.Projection = pj;
            }
            else
            {
                ProjectionTargetObject.RotationX = ((PlaneProjection)feTargetObject.Projection).RotationX;
                ProjectionTargetObject.RotationY = ((PlaneProjection)feTargetObject.Projection).RotationY;
            }
            BasePoint.X = Canvas.GetLeft(feTargetObject);
            BasePoint.Y = Canvas.GetTop(feTargetObject);
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            if (feSourceObject != null)
            {
                feSourceObject.MouseEnter -= new MouseEventHandler(feSourceObject_MouseEnter);
                feSourceObject.MouseLeave -= new MouseEventHandler(feSourceObject_MouseLeave);
                feSourceObject.MouseMove -= new MouseEventHandler(feSourceObject_MouseMove);
            }
        }

        void feSourceObject_MouseMove(object sender, MouseEventArgs e)
        {
            if (feTargetObject.Visibility == Visibility.Collapsed)
                return;

            Point p = GetDestinationAngleXY(e);
            AnimateToAngleXY(p);
        }
        void feSourceObject_MouseLeave(object sender, MouseEventArgs e)
        {
            if (feTargetObject.Visibility == Visibility.Collapsed)
                return;

            AnimateToAngleXY(new Point(0, 0));
        }

        void feSourceObject_MouseEnter(object sender, MouseEventArgs e)
        {
            if (feTargetObject.Visibility == Visibility.Collapsed)
                return;

            Point p = GetDestinationAngleXY(e);
            AnimateToAngleXY(p);
        }

        private Point GetDestinationAngleXY(MouseEventArgs e)
        {
            DetermineSourceWidthAndHeight();
            double x = 0;
            double y = 0;
            Point actualPos = e.GetPosition(feSourceObject);
            Point pCenter = new Point(SourceWidth / 2, SourceHeight / 2);
            if (ProjectionTowardsMouse == false)
            {
                y = (actualPos.X - pCenter.X) / pCenter.X * AmplitudeAngleX;
                x = (pCenter.Y - actualPos.Y) / pCenter.Y * AmplitudeAngleY;
            }
            else
            {
                y = (pCenter.X - actualPos.X) / pCenter.X * AmplitudeAngleX;
                x = (actualPos.Y - pCenter.Y) / pCenter.Y * AmplitudeAngleY;
            }
            return new Point(x, y);
        }

        private void AnimateToAngleXY(Point XY)
        {
            Point XY_Adjusted = XY;
            double SlideX = GetDestinationSlide(XY.Y, AmplitudeAngleY, AmplitudeSlideX);
            double SlideY = GetDestinationSlide(XY.X, AmplitudeAngleX, AmplitudeSlideY);
            double Adjusted_SlideX = SlideX + BasePoint.X;
            double Adjusted_SlideY = SlideY + BasePoint.Y;
            playAnimation(feTargetObject, "(Canvas.Left)", tsAnimationTime, Adjusted_SlideX, SB_X, Easing);
            playAnimation(feTargetObject, "(Canvas.Top)", tsAnimationTime, Adjusted_SlideY, SB_Y, Easing);
        }

        public static void playAnimation(FrameworkElement element, string property, TimeSpan time, double value, Storyboard sb, IEasingFunction EasingFunction)
        {
            sb = new Storyboard();
            sb.Children.Clear();
            DoubleAnimation animation = new DoubleAnimation();
            animation.Duration = time;
            animation.To = value;
            animation.EasingFunction = EasingFunction;
            Storyboard.SetTargetProperty(animation, new PropertyPath(property));
            Storyboard.SetTarget(animation, element);
            sb.Children.Add(animation);
            sb.Begin();
        }
        private double GetDestinationSlide(double CalculatedAngle, double AmplitudeAngle, double AmplitudeSlide)
        {
            double CalculatedSlide = 0;
            CalculatedSlide = CalculatedAngle * (AmplitudeSlide/AmplitudeAngle);
            return CalculatedSlide;
        }
    }
}
