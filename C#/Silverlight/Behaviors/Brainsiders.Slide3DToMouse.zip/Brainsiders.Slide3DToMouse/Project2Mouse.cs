﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;
using System.ComponentModel;


namespace Brainsiders.Slide3DToMouse
{
    [Description("Project2Mouse - A behavior that enables a projection over the X and Y angles in response to mouse movement.")]
    public class Project2Mouse : TargetedTriggerAction<FrameworkElement>
    {
        [Description("Angle animation duration (in milliseconds)")]
        [Category("Projection Animation Properties")]
        public int AnimationTime { get; set; } 

        [Description("The Easing Function assigned to the animation")]
        [Category("Projection Animation Properties")]
        public IEasingFunction Easing { get; set; }

        [Description("The Positive/Negative X Angle amplitude for the perspective transform")]
        [Category("Projection Animation Properties")]
        public double AmplitudeAngleX { get; set; }

        [Description("The Positive/Negative Y Angle amplitude for the perspective transform")]
        [Category("Projection Animation Properties")]
        public double AmplitudeAngleY { get; set; }


        [Description("If the projection is oriented towards the mouse or against it.")]
        [Category("Projection Animation Properties")]
        public Boolean ProjectionTowardsMouse { get; set; }

        private TimeSpan tsAnimationTime;
        private FrameworkElement feAssociatedObject;
        private FrameworkElement feSourceObject;
        private FrameworkElement feTargetObject;

        private double SourceWidth;
        private double SourceHeight;
        private Storyboard SB_X;
        private Storyboard SB_Y;

        protected override void Invoke(object parameter)
        {
            FrameworkElement myElement = this.AssociatedObject as FrameworkElement;
        }

        protected override void OnAttached()
        {
            base.OnAttached();
            feAssociatedObject = (FrameworkElement)this.AssociatedObject;
            feSourceObject = (FrameworkElement)this.AssociatedObject;
            tsAnimationTime = new TimeSpan(0, 0, 0, 0, AnimationTime);
            feSourceObject.Loaded += new RoutedEventHandler(feSourceObject_Loaded);
        }

        private void DetermineSourceWidthAndHeight()
        {
            if (double.IsNaN(feSourceObject.ActualWidth) || feSourceObject.ActualWidth == 0)
            {
                SourceWidth = feSourceObject.Width;
            }
            else
            {
                SourceWidth = feSourceObject.ActualWidth;
            }

            if (double.IsNaN(feSourceObject.ActualHeight) || feSourceObject.ActualHeight == 0)
            {
                SourceHeight = feSourceObject.Height;
            }
            else
            {
                SourceHeight = feSourceObject.ActualHeight;
            }
        }

        void feSourceObject_Loaded(object sender, RoutedEventArgs e)
        {
            DetermineSourceWidthAndHeight();
            feSourceObject.MouseEnter += new MouseEventHandler(feSourceObject_MouseEnter);
            feSourceObject.MouseLeave += new MouseEventHandler(feSourceObject_MouseLeave);
            feSourceObject.MouseMove += new MouseEventHandler(feSourceObject_MouseMove);

            feTargetObject = (FrameworkElement)this.TargetObject;
            if (feTargetObject.Projection == null)
            {
                feTargetObject.RenderTransformOrigin = new Point(0.5, 0.5);
                PlaneProjection pj = new PlaneProjection();
                feTargetObject.Projection = pj;
            }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            if (feSourceObject != null)
            {
                feSourceObject.MouseEnter -= new MouseEventHandler(feSourceObject_MouseEnter);
                feSourceObject.MouseLeave -= new MouseEventHandler(feSourceObject_MouseLeave);
                feSourceObject.MouseMove -= new MouseEventHandler(feSourceObject_MouseMove);
            }
        }

        void feSourceObject_MouseMove(object sender, MouseEventArgs e)
        {
            Point p = GetDestinationAngleXY(e);
            AnimateToAngleXY(p);
        }
        void feSourceObject_MouseLeave(object sender, MouseEventArgs e)
        {
            AnimateToAngleXY(new Point(0, 0));
        }

        void feSourceObject_MouseEnter(object sender, MouseEventArgs e)
        {
            Point p = GetDestinationAngleXY(e);
            AnimateToAngleXY(p);
        }

        private Point GetDestinationAngleXY(MouseEventArgs e)
        {
            if (((this.SourceHeight == 0) || (this.SourceWidth == 0)) || ((Double.IsNaN(this.SourceHeight) == true) || (Double.IsNaN(this.SourceWidth) == true)))
            {
                DetermineSourceWidthAndHeight();
            }

            double x = 0;
            double y = 0;
            Point actualPos = e.GetPosition(feSourceObject);
            Point pCenter = new Point(SourceWidth / 2, SourceHeight / 2);
            if (ProjectionTowardsMouse == false)
            {
                y = (actualPos.X - pCenter.X) / pCenter.X * AmplitudeAngleX;
                x = (pCenter.Y - actualPos.Y) / pCenter.Y * AmplitudeAngleY;
            }
            else
            {
                y = (pCenter.X - actualPos.X) / pCenter.X * AmplitudeAngleX;
                x = (actualPos.Y - pCenter.Y) / pCenter.Y * AmplitudeAngleY;
            }
            return new Point(x, y);
        }

        private void AnimateToAngleXY(Point XY)
        {
            playAnimation(feTargetObject, "(UIElement.Projection).(PlaneProjection.RotationX)", tsAnimationTime, XY.X, SB_X, Easing);
            playAnimation(feTargetObject, "(UIElement.Projection).(PlaneProjection.RotationY)", tsAnimationTime, XY.Y, SB_Y, Easing);
        }

        public static void playAnimation(FrameworkElement element, string property, TimeSpan time, double value, Storyboard sb, IEasingFunction EasingFunction)
        {
            sb = new Storyboard();
            sb.Children.Clear();
            DoubleAnimation animation = new DoubleAnimation();
            animation.Duration = time;
            animation.To = value;
            animation.EasingFunction = EasingFunction;
            Storyboard.SetTargetProperty(animation, new PropertyPath(property));
            Storyboard.SetTarget(animation, element);
            sb.Children.Add(animation);
            sb.Begin();
        }
    }
}
