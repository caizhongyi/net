﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Interactivity;
using System.ComponentModel;

namespace Behaviors
{
    public class ClipToBoundsBehavior : Behavior<FrameworkElement>
    {
        protected override void OnAttached()
        {
            base.OnAttached();

            AssociatedObject.Clip = Clip(new Size(AssociatedObject.ActualWidth, AssociatedObject.ActualHeight));
            AssociatedObject.SizeChanged += new SizeChangedEventHandler(AssociatedObject_SizeChanged);
        }
        protected override void OnDetaching()
        {
            base.OnDetaching();

            AssociatedObject.SizeChanged -= AssociatedObject_SizeChanged;
            AssociatedObject.Clip = null;
        }

        private void AssociatedObject_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            AssociatedObject.Clip = Clip(e.NewSize);
        }

        private Geometry Clip(Size size)
        {
            if (IsInverted)
            {
                GeometryGroup gg = new GeometryGroup() { FillRule = FillRule.EvenOdd };
                gg.Children.Add(new RectangleGeometry() { Rect = new Rect(-15, -15, size.Width + 30, size.Height + 30), RadiusX = RadiusX, RadiusY = RadiusY });
                gg.Children.Add(new RectangleGeometry() { Rect = new Rect(0, 0, size.Width, size.Height), RadiusX = RadiusX, RadiusY = RadiusY });

                return gg;
            }
            else
                return new RectangleGeometry() { Rect = new Rect(0, 0, size.Width, size.Height), RadiusX = RadiusX, RadiusY = RadiusY };
        }

        [Category("Common Properties")]
        public double RadiusX { get; set; }
        [Category("Common Properties")]
        public double RadiusY { get; set; }

        [Category("Common Properties")]
        public bool IsInverted { get; set; }
    }
}