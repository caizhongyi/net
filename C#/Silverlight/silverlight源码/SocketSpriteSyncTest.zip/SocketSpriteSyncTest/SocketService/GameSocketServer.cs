﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.IO;

namespace SocketService
{
    public class GameSocketServer
    {
        //System.Timers.Timer timer = null;
        public TcpListener Listener { get; set; }
        public AsyncCallback WorkerCallback { get; set; }

        static ManualResetEvent ClientConnected = new ManualResetEvent(false);
        List<GameClientSocketPacket> clientList = new List<GameClientSocketPacket>();

        public void Start()
        {
            //timer = new System.Timers.Timer();
            //timer.Enabled = false;
            //timer.Interval = 2000D;
            //timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);

            //Allowed port range for Silverlight: 4502-4532

            //create the listening socket...
            //Listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            Listener = new TcpListener(IPAddress.Any, 4530);
            Listener.Start();
            //IPEndPoint ipLocal = new IPEndPoint(IPAddress.Any, 4530);
            ////bind to local IP Address...
            //Listener.Bind(ipLocal);
            //start listening...
            //Listener.Listen(4);

            Console.WriteLine("Server started.");

            while (true)
            {
                // Set the event to nonsignaled state.
                ClientConnected.Reset();

                // create the call back for any client connections...
                //Listener.BeginAccept(new AsyncCallback(OnClientConnect), null);
                Listener.BeginAcceptTcpClient(new AsyncCallback(OnClientConnect), null);
                ClientConnected.WaitOne(); //Block until client connects
            }
        }

        public void OnClientConnect(IAsyncResult ar)
        {
            try
            {
                // Signal the main thread to continue.
                ClientConnected.Set();
                TcpListener listener = Listener;

                //Create a packet to hold the client state
                GameClientSocketPacket client = new GameClientSocketPacket();
                client.tcpClient = Listener.EndAcceptTcpClient(ar);

                if (client.tcpClient.Connected)
                {
                    client.clientStream = new StreamWriter(client.tcpClient.GetStream());
                    client.clientStream.AutoFlush = true;

                    //Add socket to client list
                    clientList.Add(client);

                    //Wait for incoming data
                    WaitForData(client);

                    Console.WriteLine("New client connected.");
                    SendData("New client connected.>");
                }

                //if (timer.Enabled == false)
                //{
                //    timer.Start();
                //}
            }
            catch (ObjectDisposedException)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\n OnClientConnection: Socket has been closed\n");
            }
            catch (SocketException se)
            {
                Console.WriteLine(se.Message);
            }

        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            //SendData(string.Format("Demo server push message every 10 seconds ({0})", DateTime.Now.ToString("hh:mm:ss")));
            //Interval to push data
            //10 seconds
            //timer.Interval = 10000;
        }

        /// <summary>
        /// Send data to all clients
        /// </summary>
        /// <param name="data"></param>
        private void SendData(string data)
        {
            //For each connected client
            foreach (GameClientSocketPacket client in clientList)
            {
                try
                {
                    if (client.tcpClient.Connected)
                        client.clientStream.Write(data);
                }
                catch
                {
                    //Error, client is disconnected
                    //Remove client from list
                    client.tcpClient.Close();
                }
            }

            //Remove all closed sockets
            CleanList();

        }

        /// <summary>
        /// Clean list / Remove all closed sockets
        /// </summary>
        private void CleanList()
        {
            List<GameClientSocketPacket> cleanList = new List<GameClientSocketPacket>();
            foreach (GameClientSocketPacket client in clientList)
            {
                if (client.tcpClient.Connected)
                    cleanList.Add(client);

            }
            clientList = cleanList;
        }

        /// <summary>
        /// Wait for incoming data
        /// </summary>
        /// <param name="clientPacket"></param>
        public void WaitForData(GameClientSocketPacket clientPacket)
        {
            try
            {
                if (WorkerCallback == null)
                {
                    WorkerCallback = new AsyncCallback(OnDataReceived);
                }

                // now start to listen for any data...
                clientPacket.tcpClient.Client.BeginReceive(clientPacket.dataBuffer, 0, clientPacket.dataBuffer.Length, SocketFlags.None, WorkerCallback, clientPacket);
            }
            catch (SocketException se)
            {
                Console.WriteLine(se.Message);
            }

        }


        /// <summary>
        /// Incoming data from client
        /// </summary>
        /// <param name="asyn"></param>
        public void OnDataReceived(IAsyncResult asyn)
        {

            try
            {
                string content = string.Empty;

                GameClientSocketPacket clientPacket = (GameClientSocketPacket)asyn.AsyncState;
                //end receive...

                int bytesRead = clientPacket.tcpClient.Client.EndReceive(asyn);

                if (bytesRead > 0)
                {
                    string receivedString = Encoding.ASCII.GetString(clientPacket.dataBuffer, 0, bytesRead);
                    clientPacket.clientStream.Write(receivedString);

                    clientPacket.tcpClient.Client.BeginReceive(clientPacket.dataBuffer, 0, clientPacket.dataBuffer.Length, 0, new AsyncCallback(this.WorkerCallback), clientPacket);

                    //Dirty way of getting the full string
                    //This can be done a lot better / more complex
                    //See for example: http://www.codeproject.com/KB/IP/AsyncSocketServerandClien.aspx
                    if (clientPacket.tcpClient.Client.Available == 0 && receivedString == ">")
                    {
                        string strContent;
                        strContent = clientPacket.receivedTextSB.ToString();
                        if (strContent.Length > 0)
                            strContent = strContent.Substring(0, strContent.Length - 1);
                        clientPacket.receivedTextSB = new StringBuilder();
                        Console.WriteLine(strContent);

                        Log(strContent);

                        //Send data to all clients
                        SendData(strContent);

                    }
                }

            }
            catch (System.Net.Sockets.SocketException es)
            {
                if (es.ErrorCode != 64)
                {
                    Console.WriteLine(string.Format("ReadCallback Socket Exception: {0}, {1}.", es.ErrorCode, es.ToString()));
                }
            }
            catch (Exception e)
            {
                if (e.GetType().FullName != "System.ObjectDisposedException")
                {
                    Console.WriteLine(string.Format("ReadCallback Exception: {0}.", e.ToString()));
                }
            }
        }

        private static void Log(string strContent)
        {
            FileInfo t = new FileInfo("ChatLog.txt");
            StreamWriter Tex = t.AppendText();
            Tex.WriteLine(DateTime.Now.ToString() + " | " + strContent);
            Tex.Close();
        }
    }
}
