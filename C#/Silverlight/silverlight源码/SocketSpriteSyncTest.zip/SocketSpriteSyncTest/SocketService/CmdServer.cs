﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Collections;

namespace SocketService
{
    /// <summary>
    /// This is a simple server console application that uses asynchronous TCP Sockets to receive chat messages and
    /// distribute them to all connected clients.
    /// 
    /// Copyright: The code is freely distributable, but I'd appreciate credits if you use it in your projects.
    /// Author: Claus Topholt (claus@topholt.com) February 2008.
    /// </summary>
    public class CmdServer
    {
        // Server connectivity variables.
        private static IPEndPoint _serverIPEndPoint;
        private static Socket _serverSocket;

        // Connection Loop control variables.
        private static ManualResetEvent _manualResetEvent;
        private static Boolean _continueRunning;

        // Other server variables.
        private static Hashtable _connectedClientSockets;
        private static int _receivedDatagramsCount;

        public void StartServer()
        {
            try
            {
                // Get the server port from the app.config.
                Int16 serverPort = Convert.ToInt16(ConfigurationManager.AppSettings["ServerPort"]);

                // Create an IPEndPoint for the Server and the Server socket (the listener).
                _serverIPEndPoint = new IPEndPoint(IPAddress.Any, serverPort);
                _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                // Bind the Server Socket and start listening.
                _serverSocket.Bind(_serverIPEndPoint);
                _serverSocket.Listen(100);

                // Create the connected clients Hashtable, which will contain Sockets identified by their RemoteEndPoints as keys.
                _connectedClientSockets = new Hashtable();

                // Reset the counter of received datagrams to 0.
                _receivedDatagramsCount = 0;

                // Output debug info.
                Debug.WriteLine("Server started.");
                Console.WriteLine("Server started.");
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }

        public void ShutdownServer()
        {
            try
            {
                // Shut down the server loop.
                _continueRunning = false;

                // Signal to let the thread continue, thus ending the loop.
                _manualResetEvent.Set();

                // Output debug info.
                Debug.WriteLine("Server shutdown.");
                Console.WriteLine("Server shutdown.");
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
            }
        }

        public void ConnectionLoop()
        {
            try
            {
                // Output debug info.
                Debug.WriteLine("Waiting for connections..");
                Console.WriteLine("Waiting for connections...");

                // Create a ManualResetEvent in non-signaled state, which is used to control the ConnectionLoop().
                _manualResetEvent = new ManualResetEvent(false);

                // Make sure the listen-loop runs.
                _continueRunning = true;

                // Loop until someone sets _continueRunning to false (and signals _manualResetEvent).
                while (_continueRunning)
                {
                    // Reset to non-signaled.
                    _manualResetEvent.Reset();

                    // Set the BeginAccept callback to accept incoming connections.
                    _serverSocket.BeginAccept(new AsyncCallback(BeginAcceptConnection), _serverSocket);

                    // Wait until signaled.
                    _manualResetEvent.WaitOne();
                }
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }

        private void BeginAcceptConnection(IAsyncResult asyncResult)
        {
            try
            {
                // Signal to let the thread continue.
                _manualResetEvent.Set();

                // Get the server socket.
                Socket serverSocket = (Socket)asyncResult.AsyncState;

                // Call EndAccept to complete the connection and get a client Socket.
                Socket clientSocket = serverSocket.EndAccept(asyncResult);

                // Create a StateObject, which holds received data.
                StateObject stateObject = new StateObject(clientSocket.RemoteEndPoint.ToString());

                // Add the clientSocket to a list, using the clientSocket's endpoint as a key.
                _connectedClientSockets.Add(clientSocket.RemoteEndPoint.ToString(), clientSocket);

                // Set the BeginReceive callback to accept incoming data, which is a 256 byte datagram.
                clientSocket.BeginReceive(stateObject.DatagramBuffer, 0, 256, SocketFlags.None, new AsyncCallback(BeginReceiveDatagram), stateObject);

                // Output debug info.
                Debug.WriteLine("Connection established by client on " + clientSocket.RemoteEndPoint.ToString());
                Console.WriteLine("Connection established by client on " + clientSocket.RemoteEndPoint.ToString());
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }

        private void BeginReceiveDatagram(IAsyncResult asyncResult)
        {
            try
            {
                // Get the datagram message (always 256 bytes).
                // Token, Userid, 

                // Get the StateObject and from there, the client Socket.
                StateObject stateObject = (StateObject)asyncResult.AsyncState;
                Socket clientSocket = (Socket)_connectedClientSockets[stateObject.ClientEndPointKey];

                // Read the number of bytes from the client Socket that was defined in the header.
                Int32 bytesReceivedCount = clientSocket.EndReceive(asyncResult);

                // Increment the received bytes count.
                stateObject.ReceivedBytes += bytesReceivedCount;

                // If the number of received bytes does not match the expected length, keep receiving.
                if (stateObject.ReceivedBytes < stateObject.DatagramBuffer.Length)
                {
                    clientSocket.BeginReceive(stateObject.DatagramBuffer, stateObject.ReceivedBytes, (stateObject.DatagramBuffer.Length - stateObject.ReceivedBytes), SocketFlags.None, new AsyncCallback(BeginReceiveDatagram), stateObject);
                    return;
                }

                // If no bytes were read, perhaps the Socket was shutdown by client. In any case, stop here.
                if (bytesReceivedCount == 0) return;

                // Increment the counter.
                Interlocked.Increment(ref _receivedDatagramsCount);

                // Process the message.
                ProcessDatagram(stateObject);

                // Ready to receive another datagram!
                clientSocket.BeginReceive(stateObject.DatagramBuffer, 0, 256, SocketFlags.None, new AsyncCallback(BeginReceiveDatagram), stateObject);
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }

        private void ProcessDatagram(StateObject stateObject)
        {
            try
            {
                String datagram = Encoding.UTF8.GetString(stateObject.DatagramBuffer);
                Debug.WriteLine("Received datagram: " + datagram);
                Console.WriteLine("Received datagram: " + datagram);

                // Distribute the datagram to all connected clients.
                DistributeMessage(datagram);

                // Things to consider implementing:
                // Process the datagram message (the stateObject).
                // Authorize it (token, userid match).
                // Persist it.
                // Distribute it to all members of the specific room.
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }

        private void DistributeMessage(String datagram)
        {
            // Distribute one message to all members of a specific room. Rooms NIY!
            foreach (Socket socket in _connectedClientSockets.Values)
            {
                if (socket.Connected)
                {
                    SendMessage(socket.RemoteEndPoint.ToString(), datagram);
                }
            }
        }

        private void SendMessage(String ClientEndPointKey, String Message)
        {
            try
            {
                // Get the client Socket from the connected clients list.
                Socket clientSocket = (Socket)_connectedClientSockets[ClientEndPointKey];

                // Create a datagram of 256 bytes.
                Byte[] datagram = new Byte[256];

                // Encode the datagram.
                datagram = Encoding.UTF8.GetBytes(Message);

                // Send message.
                clientSocket.Send(datagram);
            }
            catch (Exception ex)
            {
                // Something went wrong. Output details.
                Debug.WriteLine(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
