﻿/*
 * Copyright Michiel Post
 * http://www.michielpost.nl
 * contact@michielpost.nl
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;

namespace SocketService
{
    /// <summary>
    /// Socket state packet
    /// </summary>
    public class ClientSocketPacket
    {
        public Socket clientSocket;
        public byte[] dataBuffer = new byte[1];
        public StringBuilder receivedTextSB = new StringBuilder();
    }
}
