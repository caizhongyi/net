﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO;

namespace SocketService
{
    public class GameClientSocketPacket
    {
        public TcpClient tcpClient;
        public byte[] dataBuffer = new byte[1];
        public StringBuilder receivedTextSB = new StringBuilder();
        public StreamWriter clientStream;
    }
}
