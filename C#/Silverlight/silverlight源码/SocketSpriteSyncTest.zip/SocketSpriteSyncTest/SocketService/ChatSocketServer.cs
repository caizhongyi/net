﻿/*
 * Copyright Michiel Post
 * http://www.michielpost.nl
 * contact@michielpost.nl
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Timers;
using System.Threading;
using System.IO;
using System.Net;

namespace SocketService
{
    public class ChatSocketServer
    {

        System.Timers.Timer _timer = null;

        public AsyncCallback _workerCallBack;
        public Socket _socketListener;
       
        private ManualResetEvent _allDone = new ManualResetEvent(false);
        private List<ClientSocketPacket> _clientList = new List<ClientSocketPacket>();

        public void StartSocketServer()
        {
            //Timer for automatic demo messages
            _timer = new System.Timers.Timer();
            _timer.Enabled = false;
            _timer.Interval = 2000D;
            _timer.Elapsed += new ElapsedEventHandler(TimerElapsed);


            //Allowed port range for Silverlight: 4502-4532

            //create the listening socket...
            _socketListener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ipLocal = new IPEndPoint(IPAddress.Any, 4530);
            //bind to local IP Address...
            _socketListener.Bind(ipLocal);
            //start listening...
            _socketListener.Listen(4);

            Console.WriteLine("Server started.");

            while (true)
            {
                // Set the event to nonsignaled state.
                _allDone.Reset();

                // create the call back for any client connections...
                _socketListener.BeginAccept(new AsyncCallback(OnClientConnect), null);

                // Wait until a connection is made before continuing.
                _allDone.WaitOne();

            }


        }

        public void OnClientConnect(IAsyncResult asyn)
        {
            try
            {
                // Signal the main thread to continue.
                _allDone.Set();
                
                //Create a packet to hold the client state
                ClientSocketPacket clientSocket = new ClientSocketPacket();
                clientSocket.clientSocket =  _socketListener.EndAccept(asyn);;

                //Add socket to client list
                _clientList.Add(clientSocket);

                //Wait for incoming data
                WaitForData(clientSocket);

                Console.WriteLine("New client connected.");
                SendData("New client connected");
                
                if (_timer.Enabled == false)
                {
                    _timer.Start();
                }
            }
            catch (ObjectDisposedException)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\n OnClientConnection: Socket has been closed\n");
            }
            catch (SocketException se)
            {
                Console.WriteLine(se.Message);
            }

        }


        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            SendData(string.Format("Demo server push message every 10 seconds ({0})", DateTime.Now.ToString("hh:mm:ss")));
            //Interval to push data
            //10 seconds
            _timer.Interval = 10000;
        }

        /// <summary>
        /// Send data to all clients
        /// </summary>
        /// <param name="data"></param>
        private void SendData(string data)
        {            
            byte[] byteData = System.Text.Encoding.ASCII.GetBytes(data);

            //For each connected client
            foreach (ClientSocketPacket client in _clientList)
            {
                try
                {
                    if(client.clientSocket.Connected)
                        client.clientSocket.Send(byteData);
                }
                catch
                {
                    //Error, client is disconnected
                    //Remove client from list
                    client.clientSocket.Close();                    
                }
            }
            
            //Remove all closed sockets
            CleanList();
                        
        }

        /// <summary>
        /// Clean list / Remove all closed sockets
        /// </summary>
        private void CleanList()
        {
            List<ClientSocketPacket> cleanList = new List<ClientSocketPacket>();
            foreach (ClientSocketPacket client in _clientList)
            {
                if (client.clientSocket.Connected)
                    cleanList.Add(client);

            }
            _clientList = cleanList;
        }

        /// <summary>
        /// Wait for incoming data
        /// </summary>
        /// <param name="clientPacket"></param>
        public void WaitForData(ClientSocketPacket clientPacket)
        {
            try
            {
                if (_workerCallBack == null)
                {
                    _workerCallBack = new AsyncCallback(OnDataReceived);
                }
                               
                // now start to listen for any data...
                clientPacket.clientSocket.BeginReceive(clientPacket.dataBuffer, 0, clientPacket.dataBuffer.Length, SocketFlags.None, _workerCallBack, clientPacket);
            }
            catch (SocketException se)
            {
                Console.WriteLine(se.Message);
            }

        }

   
        /// <summary>
        /// Incoming data from client
        /// </summary>
        /// <param name="asyn"></param>
        public void OnDataReceived(IAsyncResult asyn)
        {
            
            try
            {
                string content = string.Empty;
                
                ClientSocketPacket clientPacket = (ClientSocketPacket)asyn.AsyncState;
                //end receive...

                int bytesRead = clientPacket.clientSocket.EndReceive(asyn);
                
                if (bytesRead > 0)
                {
                    string receivedString = Encoding.ASCII.GetString(clientPacket.dataBuffer, 0, bytesRead);
                    clientPacket.receivedTextSB.Append(receivedString);
                    
                    clientPacket.clientSocket.BeginReceive(clientPacket.dataBuffer, 0, clientPacket.dataBuffer.Length, 0, new AsyncCallback(this._workerCallBack), clientPacket);

                    //Dirty way of getting the full string
                    //This can be done a lot better / more complex
                    //See for example: http://www.codeproject.com/KB/IP/AsyncSocketServerandClien.aspx
                    if (clientPacket.clientSocket.Available == 0 && receivedString == ">")
                    {
                        string strContent;
                        strContent = clientPacket.receivedTextSB.ToString();
                        strContent = strContent.Substring(0, strContent.Length-1);
                        clientPacket.receivedTextSB = new StringBuilder();
                        Console.WriteLine(strContent);

                        Log(strContent);

                        //Send data to all clients
                        SendData(strContent);

                    }
                }                
               
            }
            catch (System.Net.Sockets.SocketException es)
            {
                if (es.ErrorCode != 64)
                {
                    Console.WriteLine(string.Format("ReadCallback Socket Exception: {0}, {1}.", es.ErrorCode, es.ToString()));
                }
            }
            catch (Exception e)
            {
                if (e.GetType().FullName != "System.ObjectDisposedException")
                {
                    Console.WriteLine(string.Format("ReadCallback Exception: {0}.", e.ToString()));
                }
            }
        }

        private static void Log(string strContent)
        {
            FileInfo t = new FileInfo("ChatLog.txt");
            StreamWriter Tex = t.AppendText();
            Tex.WriteLine(DateTime.Now.ToString() + " | " + strContent);
            Tex.Close();
        }
    }
}

