﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace SocketService
{
    public class StateObject
    {
        public String ClientEndPointKey;
        public Byte[] DatagramBuffer;
        public Int32 ReceivedBytes;


        public StateObject(String clientEndPointKey)
        {
            // Set the client IPEndPoint.
            ClientEndPointKey = clientEndPointKey;

            // Create a datagram buffer of 256 bytes.
            DatagramBuffer = new Byte[256];

            // Reset the number of received bytes to 0.
            ReceivedBytes = 0;
        }
    }
}
