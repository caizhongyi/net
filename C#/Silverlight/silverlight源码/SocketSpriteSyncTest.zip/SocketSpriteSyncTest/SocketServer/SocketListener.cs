﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

// code shamelessly adapted from
// http://www.devx.com/dotnet/Article/28083/0/page/1

namespace ChatServer
{
    class SocketListener
    {
        private const string _portSettingsKey = "port";         // key in appsettings for our listening port
        private const string _addressSettingsKey = "address";   // key in appsettings for our listening address

        private int _port;
        private IPAddress _address;

        private TcpListener _listener; 
        
        private bool _stop = false;

        public SocketListener()
        {
            bool ok = true;

            if (!IPAddress.TryParse(ConfigurationManager.AppSettings[_addressSettingsKey], out _address))
            {
                Console.WriteLine(string.Format("Missing or invalid IP Address config value for '{0}'", _addressSettingsKey));
                ok = false;
            }

            if (!int.TryParse(ConfigurationManager.AppSettings[_portSettingsKey], out _port))
            {
                Console.WriteLine(string.Format("Missing or invalid port config value for '{0}'", _portSettingsKey));
                ok = false;
            }

            if (ok)
            {
                _listener = new TcpListener(_address, _port);
            }
        }

        public void Start()
        {
            try
            {
                if (_listener != null)
                {
                    Console.WriteLine("Starting Socket Listener");

                    _listener.Start();

                    while (true)
                    {
                        // this is a blocking call
                        SocketClient client = new SocketClient(_listener.AcceptTcpClient());
                    }
                }
            
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }


    }
}
