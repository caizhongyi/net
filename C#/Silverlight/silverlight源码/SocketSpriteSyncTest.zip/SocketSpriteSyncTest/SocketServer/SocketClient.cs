﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ChatServer
{
    class SocketClient
    {
        public static Hashtable ConnectedClients = new Hashtable();
        private TcpClient _client;
        private string _clientIP;

        private byte[] _data;

        public SocketClient(TcpClient client)
        {
            Console.WriteLine(string.Format("Starting Socket Listener for client {0}", client.Client.RemoteEndPoint.ToString()));

            _client = client;

            _clientIP = client.Client.RemoteEndPoint.ToString();

            // add client to static list of all connected clients
            ConnectedClients.Add(_clientIP, this);

            _data = new byte[_client.ReceiveBufferSize];

            _client.GetStream().BeginRead(_data, 0, _client.ReceiveBufferSize, ReceiveMessage, null);
        }

        public void ReceiveMessage(IAsyncResult ar)
        {
            int bytesRead;
            try
            {
                lock (_client.GetStream())
                {
                    bytesRead = _client.GetStream().EndRead(ar);
                }

                if (bytesRead < 1)
                {
                    ConnectedClients.Remove(_clientIP);
                    //Broadcast(_clientNickname + " left the chat");
                    Broadcast("left");

                    return;
                }

                // get the sent message
                string messageReceived = System.Text.Encoding.ASCII.GetString(_data, 0, bytesRead);

                Console.WriteLine(string.Format("Message: {0}", messageReceived));

                Broadcast(messageReceived);

                lock (_client.GetStream())
                {
                    _client.GetStream().BeginRead(_data, 0, _client.ReceiveBufferSize, ReceiveMessage, null);
                }
            }
            catch (Exception ex)
            {
                ConnectedClients.Remove(_clientIP);
                //Broadcast(_clientNickname + " left the chat.");
                Broadcast("The other party left the chat.");
            }

        }

        public void SendMessage(string message)
        {
            try
            {
                NetworkStream ns;

                lock (_client.GetStream())
                {
                    ns = _client.GetStream();
                }

                byte[] bytesToSend = System.Text.Encoding.ASCII.GetBytes(message);
                ns.Write(bytesToSend, 0, bytesToSend.Length);
                ns.Flush();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public void Broadcast(string message)
        {
            System.Diagnostics.Debug.WriteLine(message);

            foreach (DictionaryEntry c in ConnectedClients)
            {
                if (((SocketClient)c.Value)._clientIP != this._clientIP)
                    ((SocketClient)c.Value).SendMessage(message);
            }
        }


    }
}
