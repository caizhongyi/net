﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SocketSpriteSyncTest
{
    public class SocketClient
    {
        private const string _host = "127.0.0.1";
        private const int _port = 4530;

        private Socket _socket;
        private DnsEndPoint _endPoint;

        private bool _connected = false;

        private UIElement _dispatcherObject = new TextBlock();

        public bool IsConnected
        {
            get
            {
                return _connected;
            }
        }

        public event EventHandler<MessageEventArgs> MessageReceived;

        public SocketClient()
        {

        }

        public void Connect(string host)
        {
            _endPoint = new DnsEndPoint(host==null?_host:host, _port);
            _socket = new Socket(
                AddressFamily.InterNetwork, 
                SocketType.Stream, 
                ProtocolType.Tcp
                );

            SocketAsyncEventArgs context = new SocketAsyncEventArgs();

            context.UserToken = _socket;
            context.RemoteEndPoint = _endPoint;

            context.Completed += 
                new EventHandler<SocketAsyncEventArgs>(OnAsyncSocketOperationComplete);

            if (!_socket.ConnectAsync(context))
            {
                // this is the dumb part of sockets programming.
                // if ConnectAsync returns false, the event isn't
                // fired and you instead need to do your checking
                // here. IMHO, it should fire the event regardless

                HandleConnect(context);
            }
        }


        public void Disconnect()
        {
            _connected = false;
            _socket.Close();
        }


        void OnAsyncSocketOperationComplete(object sender, SocketAsyncEventArgs e)
        {
            switch (e.LastOperation)
            {
                case SocketAsyncOperation.Connect:
                    HandleConnect(e);
                    break;

                case SocketAsyncOperation.Receive:
                    HandleReceive(e);
                    break;

                case SocketAsyncOperation.Send:
                    break;
            }
        }

        // Handles the connect event, and starts receiving
        private void HandleConnect(SocketAsyncEventArgs context)
        {
            if (context.SocketError != SocketError.Success)
            {
                throw new SocketException((int)context.SocketError);
            }
            else
            {
                _connected = true;

                // we're connected, so start receiving
                StartReceiving();
            }
        }

        // Async receive
        private void StartReceiving()
        {
            // hey, at least it's longer than twitter :)
            byte[] buffer = new byte[255];  

            SocketAsyncEventArgs context = new SocketAsyncEventArgs();
            context.SetBuffer(buffer, 0, buffer.Length);
            context.UserToken = _socket;
            context.RemoteEndPoint = _endPoint;
            context.Completed += 
                new EventHandler<SocketAsyncEventArgs>(OnAsyncSocketOperationComplete);

            if (!_socket.ReceiveAsync(context))
            {
                // same sync/async hackery as Connect.
                // Typically there wouldn't be a message here. If it
                // was the normal case that a message is always waiting,
                // this code would end up with a stackoverflow
                HandleReceive(context);
            }
        }

        // Process a newly received message
        private void HandleReceive(SocketAsyncEventArgs context)
        {
            string message = 
                Encoding.UTF8.GetString(context.Buffer, 
                    context.Offset, context.BytesTransferred);

            // raise the event on the UI thread
            _dispatcherObject.Dispatcher.BeginInvoke(
                delegate
                {
                    if (MessageReceived != null)
                        MessageReceived(this, new MessageEventArgs(message));
                });

            // set up to receive next message
            StartReceiving();
        }


        // Send a message out through the socket
        public void SendMessage(string message)
        {
            if (_connected)
            {
                byte[] bytes = Encoding.UTF8.GetBytes(message);

                SocketAsyncEventArgs context = new SocketAsyncEventArgs();
                context.SetBuffer(bytes, 0, bytes.Length);
                context.UserToken = _socket;
                context.RemoteEndPoint = _endPoint;
                context.Completed += 
                    new EventHandler<SocketAsyncEventArgs>(OnAsyncSocketOperationComplete);

                _socket.SendAsync(context);
            }
            else
                throw new SocketException((int)SocketError.NotConnected);
        }

    }
}
