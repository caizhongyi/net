﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GameHelpers;
using GameHelpers.Timers;
using GameHelpers.Keyboard;
using System.Net.Sockets;
using System.IO;
using System.Text;

namespace SocketSpriteSyncTest
{
    public partial class Page : UserControl
    {
        private StoryboardGameLoop gameTimer;
        private KeyHandler keyHandler;

        private SocketClient socketClient;

        delegate void ShowReveicedTextHandler(string data);

        public Page()
        {
            InitializeComponent();

            socketClient = new SocketClient();

            this.Loaded += new RoutedEventHandler(Page_Loaded);
        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            socketClient.Connect(Application.Current.Host.Source.DnsSafeHost);
            socketClient.MessageReceived += new EventHandler<MessageEventArgs>(socketClient_MessageReceived);

            keyHandler = new KeyHandler(this);

            gameTimer = new StoryboardGameLoop(this.GameRoot);
            gameTimer.Update += new GameLoop.UpdateHandler(gameTimer_Update);
            gameTimer.Start();
        }

        void socketClient_MessageReceived(object sender, MessageEventArgs e)
        {
            ParseReceivedData(e.Message);
        }

        private void ParseReceivedData(string data)
        {
            ShowReveicedText(data);

            if (data.IndexOf(":") < 0)
                return;

            string[] parts = data.Split(",".ToCharArray());
            double x = Convert.ToDouble(parts[0].Substring(parts[0].IndexOf(":") + 1));
            double y = Convert.ToDouble(parts[1].Substring(parts[1].IndexOf(":") + 1));

            this.player.SetValue(Canvas.LeftProperty, x);
            this.player.SetValue(Canvas.TopProperty, y);
        }

        /// <summary>
        /// Print text on screen
        /// </summary>
        /// <param name="data"></param>
        private void ShowReveicedText(string data)
        {
            this.ChatConsole.Text += data + "\n";
            this.ScrollBar.ScrollToVerticalOffset(this.ScrollBar.ScrollableHeight);
        }


        void gameTimer_Update(TimeSpan elapsed)
        {
            bool changed = false;
            if (keyHandler.IsKeyPressed(Key.Up))
            {
                double d = ((double)this.player.GetValue(Canvas.TopProperty));
                this.player.SetValue(Canvas.TopProperty, d - 1);
                changed = true;
            }
            if (keyHandler.IsKeyPressed(Key.Down))
            {
                double d = ((double)this.player.GetValue(Canvas.TopProperty));
                this.player.SetValue(Canvas.TopProperty, d + 1);
                changed = true;
            }
            if (keyHandler.IsKeyPressed(Key.Left))
            {
                double d = ((double)this.player.GetValue(Canvas.LeftProperty));
                this.player.SetValue(Canvas.LeftProperty, d - 1);
                changed = true;
            }
            if (keyHandler.IsKeyPressed(Key.Right))
            {
                double d = ((double)this.player.GetValue(Canvas.LeftProperty));
                this.player.SetValue(Canvas.LeftProperty, d + 1);
                changed = true;
            }

            if (changed)
            {
                string data = String.Format("X:{0},Y:{1}", this.player.GetValue(Canvas.LeftProperty).ToString(), this.player.GetValue(Canvas.TopProperty).ToString());
                socketClient.SendMessage(data);
            }
        }

        private void Disconnect_Click(object sender, RoutedEventArgs e)
        {
            if (socketClient.IsConnected)
            {
                socketClient.Disconnect();
                this.Disconnect.Content = "Connect";
            }
            else
            {
                socketClient.Connect(Application.Current.Host.Source.DnsSafeHost);
                this.Disconnect.Content = "Disconnect";
            }
        }
    }
}
