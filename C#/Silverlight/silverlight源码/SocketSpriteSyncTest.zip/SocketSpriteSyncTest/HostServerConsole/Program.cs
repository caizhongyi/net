﻿/*
 * Copyright Michiel Post
 * http://www.michielpost.nl
 * contact@michielpost.nl
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Net.Sockets;
using System.Net;
using System.IO;
using SocketService;
using System.Diagnostics;

namespace ChatHost
{
    class Program
    {
        //static void Main(string[] args)
        //{           
        //    //Start socket
        //    GameSocketServer server = new GameSocketServer();
        //    server.Start();
                       
        //}

        public static void Main(string[] args)
        {
            CmdServer server = new CmdServer();
            // Start up the server.
            server.StartServer();

            // Start the ConnectionLoop.
            server.ConnectionLoop();

            // Shutdown the server.
            server.ShutdownServer();

            // Output debug info.
            Debug.WriteLine("All done; exiting server application.");
        }


      
    }
}
