﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace GameHelpers.Timers
{
    public abstract class GameLoop
    {
        protected DateTime lastTick;
        public delegate void UpdateHandler(TimeSpan elapsed);
        public event UpdateHandler Update;

        public void Tick()
        {
            DateTime now = DateTime.Now;
            TimeSpan elapsed = now - lastTick;
            lastTick = now;
            if (Update != null) Update(elapsed);
        }

        public virtual void Start()
        {
            lastTick = DateTime.Now;
        }

        public virtual void Stop()
        {
        }
    }
}
