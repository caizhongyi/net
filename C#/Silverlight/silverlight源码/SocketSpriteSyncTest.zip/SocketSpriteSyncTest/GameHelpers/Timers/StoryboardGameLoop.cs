﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace GameHelpers.Timers
{
    public class StoryboardGameLoop : GameLoop
    {
        bool stopped = true;
        Storyboard gameLoop = new Storyboard();

        public StoryboardGameLoop(FrameworkElement parent) : this(parent, 0)
        {
            
        }

        public StoryboardGameLoop(FrameworkElement parent, double milliseconds)
        {
            gameLoop.Duration = TimeSpan.FromMilliseconds(milliseconds);
            gameLoop.SetValue(FrameworkElement.NameProperty, "gameloop");
            parent.Resources.Add("gameLoop", gameLoop);
            gameLoop.Completed += new EventHandler(gameLoop_Completed);
        }

        public override void Start()
        {
            stopped = false;
            gameLoop.Begin();
            base.Start();
        }

        public override void Stop()
        {
            stopped = true;
            base.Stop();
        }

        void gameLoop_Completed(object sender, EventArgs e)
        {
            if (stopped) return;
            base.Tick();
            (sender as Storyboard).Begin();
        }
    }
}
