﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using FarseerGames.FarseerPhysics.Collisions;

namespace GameHelpers.Physics
{
    public class PhysicsHelpers
    {
        /// <summary>
        /// Use this helper method to create a Path object from a set of vertices 
        ///     use to create the Geom object for your Farseer Physics Body.  
        ///     This will allow you to visually see the shape and location of your
        ///     Geom object in relation to your sprite.  
        /// </summary>
        /// <param name="vertices"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        public static Path CreatePathFromVertices(Vertices vertices, double width, double height)
        {
            Path path = new Path();
            path.Stroke = new SolidColorBrush(Colors.Magenta);
            path.StrokeThickness = 1;
            path.Fill = new SolidColorBrush(Colors.Transparent);
            PathGeometry pathGeom = new PathGeometry();
            PathFigureCollection figures = new PathFigureCollection();
            pathGeom.Figures = figures;
            PathFigure figure = new PathFigure();
            figure.StartPoint = new Point((double)vertices[0].X, (double)vertices[0].Y);
            figure.Segments = new PathSegmentCollection();
            pathGeom.Figures.Add(figure);

            foreach (var vector in vertices)
            {
                LineSegment line = new LineSegment() { Point = new Point((double)vector.X, (double)vector.Y) };
                figure.Segments.Add(line);
            }

            TranslateTransform trans = new TranslateTransform();
            trans.X = width / 2;
            trans.Y = height / 2;
            path.RenderTransform = trans;

            path.Data = pathGeom;
            return path;
        } 
    }
}
